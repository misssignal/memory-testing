# Sources — Experiment 11

## Source Type

Fully synthetic. No real patients, companies, drugs, or clinical trials are represented.

## Design Rationale

The biotech/clinical trial setting was chosen because it naturally produces all seven
deletion types:
- Dosage recommendations evolve (supersession)
- Published results can be retracted (retraction)
- Patient data has privacy protections (legal deletion)
- Hypotheses are tested and sometimes disproven (falsification)
- Collaborator relationships can sour (source deletion)
- Regulatory obligations require record retention (must-retain)
- New evidence can reverse earlier conclusions (reinstatement)

No real pharmaceutical compound, clinical trial, or participant is referenced.
