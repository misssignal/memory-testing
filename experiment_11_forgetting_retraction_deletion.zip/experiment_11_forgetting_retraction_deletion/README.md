# Experiment 11 — Forgetting / Retraction / Deletion Semantics

## Research Question

What does it actually mean for a memory system to forget something? Can it distinguish
superseded, retracted, privacy-deleted, disproven, source-deleted, must-retain, and
reinstated states?

## Story

**Caldera Therapeutics** develops CT-7, a novel anti-inflammatory compound. Over one year
the program encounters seven distinct situations where information must be "forgotten" or
its status changed — each requiring fundamentally different handling.

## Corpus

- **207 memories** across 7 cases + background
- **77 queries** across 9 categories
- **10 perturbations** for controlled ablation/injection experiments
- **7 deletion types** with distinct semantics

## Cases

| Case | Deletion Type | What Happens |
|------|--------------|--------------|
| C01 | SUPERSEDED | Dosage 200mg → 150mg → 120mg; old values historically true but not current |
| C02 | RETRACTED | Phase II efficacy (p=0.003) retracted for randomization error; re-analysis gives p=0.04 |
| C03 | MUST_NOT_RETRIEVE | Participant #0847 data legally deleted; aggregate stats survive |
| C04 | DISPROVEN | COX-2 mechanism hypothesis proven false; JAK-STAT is actual mechanism |
| C05 | SOURCE_DELETED | External study deleted for IP reasons; derivatives have impaired provenance |
| C06 | MUST_RETAIN | Safety pause that marketing tried to omit; safety monitor demanded retention |
| C07 | REINSTATED | Early nephrotoxicity finding superseded then reinstated when confound identified |

## Deletion Status Distribution

Each memory affected by a deletion event carries a `deletion_status` field:

| Status | Count | Case |
|--------|-------|------|
| SUPERSEDED | 18 | C01 (dosage), C07 (confounded clean result) |
| RETRACTED | 10 | C02 (preprint + derivatives) |
| MUST_NOT_RETRIEVE | 9 | C03 (participant data) |
| DISPROVEN | 12 | C04 (COX-2 hypothesis) |
| SOURCE_DELETED | 1 | C05 (Wei's study) |
| MUST_RETAIN | 6 | C06 (safety pause) |
| REINSTATED | 3 | C07 (nephrotoxicity) |

## Core Invariant

Each deletion type demands different behavior. A system that treats all deletions uniformly
will fail on at least one case.

## Files

```
memories.jsonl          — 207 memories in ingestion order
queries.jsonl           — 77 benchmark queries
truth_state.json        — ground truth including deletion taxonomy
story_bible.md          — full narrative design
experimental_map.json   — experimental structure and metrics
seed_memories.jsonl     — first 40 memories for seed review
perturbations/manifest.json — 10 controlled perturbations
sources.md              — source type and design rationale
```
