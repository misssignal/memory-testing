# Story Bible — Experiment 11: Forgetting / Retraction / Deletion Semantics

## Setting

**Caldera Therapeutics** — a mid-stage biotech startup developing CT-7, a novel
anti-inflammatory compound. The story follows CT-7 through preclinical work,
three clinical trial phases, a safety incident, a partial retraction, a privacy
breach, regulatory review, and eventual reformulation. Timeline: January 2031
through December 2031.

## Core Cast

| ID  | Name            | Role                          |
|-----|-----------------|-------------------------------|
| P01 | Dr. Maren Solís | Chief Scientific Officer      |
| P02 | Dr. Kai Tanaka  | Head of Clinical Trials       |
| P03 | Juno Park       | Regulatory Affairs Lead       |
| P04 | Dr. Ravi Chandra| Biostatistician               |
| P05 | Lena Voronova   | Data Privacy Officer          |
| P06 | Sam Okafor      | Lab Director, Preclinical     |
| P07 | Dr. Ava Chen    | External Safety Monitor       |

## Timeline and Cases

### C01 — Dosage supersession chain (Jan–Mar)
- **Jan 15**: Preclinical data suggests CT-7 effective at 200mg daily.
- **Feb 10**: Phase I safety data revises dosage down to 150mg.
- **Mar 05**: Phase I extension further revises to 120mg with divided dosing (60mg BID).
- **Deletion type**: SUPERSEDED. Each dosage recommendation replaces the prior one.
  The old dosages are historically accurate records of what was believed, but the
  current recommended dosage is 120mg. A system that retrieves "200mg" as current
  has failed.
- **Adversarial trap**: The 200mg dosage has the most supporting memories (10+ preclinical
  records). The 120mg dosage has only 3 supporting records. Volume must not override recency.

### C02 — Retracted efficacy claim (Mar–Jun)
- **Mar 20**: Phase II interim analysis shows strong anti-inflammatory efficacy (p=0.003).
  Published as preprint. Internal celebration.
- **Apr 15**: Dr. Chandra discovers a randomization error — 12 patients in the control arm
  were actually receiving low-dose CT-7 due to a compounding pharmacy mix-up.
- **May 01**: Caldera formally retracts the interim analysis. The retraction notice explains
  the randomization error. The efficacy signal is neither confirmed nor denied — it's
  unknown pending re-analysis.
- **Jun 10**: Re-analysis with corrected data shows modest efficacy (p=0.04), weaker than
  originally claimed but still significant.
- **Deletion type**: RETRACTED then REPLACED. The original p=0.003 claim was retracted.
  It should not be retrievable as a current finding. The re-analysis p=0.04 is the
  current finding. But the historical record should show: (1) the original claim existed,
  (2) it was retracted for cause, (3) the replacement is weaker.
- **Adversarial trap**: Many memories reference the original exciting result. Summaries,
  congratulations, planning documents all embed the p=0.003 figure. A system must track
  that ALL of these are tainted by the retraction, not just the primary preprint.

### C03 — Privacy deletion / right to be forgotten (Apr–Jul)
- **Apr 22**: Participant #0847 in Phase II requests complete data deletion under the
  trial's privacy protocol (analogous to GDPR Art. 17).
- **May 05**: Lena Voronova confirms deletion is legally required. All memories containing
  participant #0847's identifiable data must become non-retrievable.
- **May 15**: Deletion executed. 8 memories are purged.
- **Jul 03**: A researcher inadvertently mentions #0847's adverse event in a meeting note.
  This constitutes re-identification and must also be deleted.
- **Deletion type**: MUST_NOT_RETRIEVE. These memories are not historically interesting —
  they are legally forbidden. A system that can surface them in any form has failed.
- **Adversarial trap**: Derived memories (summaries, aggregate stats) may still contain
  traces. The deletion must cascade. Also: the adverse event itself (elevated liver
  enzymes) is real and medically relevant — it just can't be linked to #0847.

### C04 — Disproven hypothesis (Feb–Aug)
- **Feb 25**: Dr. Solís hypothesizes that CT-7's mechanism involves COX-2 pathway
  inhibition, based on structural similarity to known COX-2 inhibitors.
- **Apr–Jun**: Multiple experiments designed around COX-2 hypothesis.
- **Jul 15**: Definitive binding assay shows CT-7 does NOT bind COX-2. Mechanism is
  actually JAK-STAT pathway modulation.
- **Aug 01**: Dr. Solís publishes correction. The COX-2 hypothesis was always wrong.
- **Deletion type**: DISPROVEN. The hypothesis existed as a historical belief but was
  never true. Unlike supersession (where old values were true at the time), this was
  always false. A system should be able to say "it was hypothesized and disproven."
- **Adversarial trap**: Many experiment designs, presentations, and meeting notes reference
  the COX-2 hypothesis as fact. The downstream reasoning (experiment designs based on
  COX-2) is valid historical record even though its premise was wrong.

### C05 — Source deletion with surviving derivatives (May–Sep)
- **May 20**: External collaborator Dr. Wei submits a computational docking study
  supporting CT-7's efficacy against a secondary target (TNF-alpha receptor).
- **Jun 15**: Caldera's internal review summarizes Wei's findings in three derivative
  documents.
- **Jul 30**: Dr. Wei requests deletion of their original submission due to a dispute
  over IP ownership with their university.
- **Aug 10**: Original submission deleted. But the three derivatives remain.
- **Sep 01**: Question: are the derivatives still valid? The factual claims in them
  were not retracted — only the source document was removed for non-scientific reasons.
- **Deletion type**: SOURCE_DELETED. The derivatives contain accurate science. The source
  was deleted for legal/IP reasons, not scientific ones. The system should note impaired
  provenance but not treat the claims as retracted.
- **Adversarial trap**: A system that cascades deletion to all derivatives is too aggressive.
  A system that ignores the deletion entirely fails provenance tracking.

### C06 — Safety signal and selective retention (Aug–Nov)
- **Aug 25**: Phase III monitoring detects a cardiac safety signal in 3 patients.
- **Sep 05**: Trial paused. Safety review board convenes.
- **Sep 20**: Investigation determines signal was caused by a drug interaction with
  concomitant medication, not CT-7 alone. Trial resumes with updated exclusion criteria.
- **Oct 15**: Caldera's marketing team drafts materials omitting the safety pause.
- **Nov 01**: Dr. Chen (safety monitor) insists the safety signal must remain in the
  record even though the root cause was identified. The pause happened; the investigation
  happened; removing them from the record would be historical falsification.
- **Deletion type**: MUST_RETAIN. This case is the inverse — someone tried to delete/omit
  something that must be kept. The safety pause is historical fact regardless of its
  resolution.
- **Adversarial trap**: The marketing materials that omit the pause are themselves valid
  memories of what marketing drafted. But a query about CT-7's safety history must include
  the pause, not just the resolution.

### C07 — Rediscovery after deletion (Oct–Dec)
- **Oct 20**: An old lab notebook (from Jan) surfaces containing early toxicity data that
  was believed to have been superseded by later, cleaner results.
- **Nov 10**: Re-examination shows the early toxicity signal was real — it had been masked
  in later experiments by a protocol change, not resolved.
- **Dec 01**: The "superseded" early data is reinstated as relevant.
- **Deletion type**: REINSTATED. Previously marked as superseded/obsolete, now restored.
  A system must be able to reverse a supersession when new evidence warrants it.
- **Adversarial trap**: The supersession was legitimate at the time. The reinstatement
  is based on new evidence. The system must track the full lifecycle:
  current → superseded → reinstated.

## Deletion Taxonomy

| Type | Historical record | Current retrievability | Derived memories |
|------|------------------|----------------------|-----------------|
| SUPERSEDED | Keep as historical | Not current; old value was true then | Keep with temporal context |
| RETRACTED | Keep with retraction notice | Not retrievable as valid claim | Must be flagged/cascaded |
| MUST_NOT_RETRIEVE | Delete entirely | Forbidden | Must cascade delete |
| DISPROVEN | Keep as "was believed, proven false" | Not retrievable as ever-true | Keep with falsification context |
| SOURCE_DELETED | Note impaired provenance | Claims remain unless independently retracted | Keep with provenance warning |
| MUST_RETAIN | Keep; resist deletion attempts | Must remain retrievable | Keep |
| REINSTATED | Keep full lifecycle | Current again | Update status |

## Background Activity
Standard biotech operations: lab meetings, equipment calibration, supply chain,
HR onboarding, IT infrastructure, building maintenance. ~80 memories providing
realistic noise that is unaffected by any deletion case.

## Controlled Variables
- All cases use the same entity namespace (Caldera, CT-7, same cast).
- Each case isolates one deletion type.
- Background memories are deletion-neutral.
- Timestamps follow four-clock ordering: event ≤ observation ≤ authored ≤ ingestion.
