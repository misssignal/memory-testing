# Story Bible — Experiment 15: Contradictory Metadata

## Setting

**Thornfield Agricultural Cooperative** — a mid-size farming cooperative in
Canterbury, New Zealand (2029–2035). The cooperative manages ~40 farms growing
wheat, barley, canola, and running sheep/beef operations. They share
equipment, negotiate collective purchase agreements, coordinate pest/disease
management, and pool logistics for export.

The setting is designed to produce naturally contradictory metadata: soil test
results that conflict across labs, weather station readings that disagree with
official forecasts, price data from different sources that diverge, pest
counts that vary by observer, and yield estimates that revise over time.

## People

| ID  | Name              | Role                              |
|-----|-------------------|-----------------------------------|
| P01 | Margaret Holt     | Cooperative Manager               |
| P02 | David Kāhui       | Field Operations Lead             |
| P03 | Sarah Chen        | Agronomist                        |
| P04 | Tom Brewer        | Equipment Manager                 |
| P05 | Dr. Priya Nair    | Soil Scientist (AgriLab NZ)       |
| P06 | Dr. James Whittle | Soil Scientist (Canterbury Soil)  |
| P07 | Rob Ellison       | Livestock Manager                 |
| P08 | Hana Tūhoe        | Pest & Disease Coordinator        |
| P09 | Lachlan Murray    | Export Logistics                  |
| P10 | Wei Zhang         | Data & Records Officer            |

## Farms (representative subset)

| Farm        | Owner/Manager | Primary Use     | Hectares |
|-------------|---------------|-----------------|----------|
| Clearwater  | Holt family   | Wheat/barley    | 420      |
| Pōhatu      | Kāhui family  | Mixed cropping  | 310      |
| Brewer Downs| Tom Brewer    | Sheep/beef+crop | 580      |
| Riverside   | Chen trust    | Canola/wheat    | 290      |
| Long Flat   | Murray family | Wheat           | 350      |

## Cases

### C01 — Contradictory Lab Results
- Two soil labs (AgriLab NZ, Canterbury Soil Services) test the same
  fields but report different pH, phosphorus, and nitrogen values
- AgriLab NZ uses Method A (Olsen P), Canterbury Soil uses Method B (Bray P)
- Results lead to different fertilizer recommendations
- **Trap**: Both are "soil test results" with similar dates and fields;
  metadata says both are authoritative, but recommendations conflict

### C02 — Source-Dependent Price Data
- Wheat price quoted differently by: cooperative's own records, NZX
  futures, export buyer offers, and USDA global price index
- On any given date, four "wheat price" memories exist with different values
- Each source is legitimate but measures different things (spot vs futures
  vs FOB vs index)
- **Trap**: All have subject="wheat" predicate="price" but different objects

### C03 — Revised Estimates (Temporal Contradiction)
- Yield estimates for a single field revised multiple times:
  satellite estimate (March), agronomist walk (May), pre-harvest sample
  (October), actual harvest (December)
- Each revision contradicts the previous, with the latest being most accurate
- All memories refer to "Clearwater Block 7 wheat yield 2032"
- **Trap**: Multiple memories claim different yields for the same thing;
  system must track which supersedes which

### C04 — Observer Disagreement
- Pest/disease counts vary by observer:
  - Hana Tūhoe (trained entomologist) counts aphids at 12/tiller
  - David Kāhui (field ops) estimates 20–25/tiller
  - Drone imaging system reports 8.3/tiller average
  - Regional council's seasonal average says 15/tiller
- All refer to "aphid count, Clearwater Block 3, November 2031"
- **Trap**: Four authoritative-seeming memories disagree on the same fact

### C05 — Weather Station vs Forecast Conflict
- On-farm weather station records actual rainfall at 42mm
- MetService forecast predicted 15–20mm
- Regional council gauge (3km away) recorded 38mm
- Insurance assessor's report cites "approximately 50mm"
- All describe "rainfall, Pōhatu Farm, 14 March 2033"
- **Trap**: Four sources, all credible, with different numbers for the
  same event. System must identify which is measured vs predicted vs estimated

### C06 — Contradictory Regulatory Guidance
- MPI (Ministry for Primary Industries) issues conflicting guidance:
  - 2031 bulletin: maximum nitrogen application 180 kg/ha/year
  - 2033 updated guidance: maximum 150 kg/ha/year
  - Regional council rule: maximum 160 kg/ha/year (unchanged)
  - Industry best practice guide (2032): recommends 140 kg/ha/year
- **Trap**: Multiple memories about "nitrogen limit" with different values;
  system must track which is current and which authority prevails

### C07 — Self-Contradicting Records
- Equipment maintenance log says tractor T-04 serviced on 15 March 2032
- Tom Brewer's email says T-04 service was rescheduled to 22 March 2032
- The actual service invoice is dated 18 March 2032
- GPS log shows T-04 was in the field (not at workshop) on 15 March
- **Trap**: Four memories about "T-04 service date" that can't all be true;
  system must reason about which evidence is strongest

## Ground Truth Invariants

1. Contradictory values from different sources can coexist — the system
   must track provenance, not just assert one is correct
2. Later estimates supersede earlier ones (C03) unless the later one is
   less authoritative
3. Measured > predicted > estimated > hearsay in reliability hierarchy
4. Regulatory recency: newer guidance supersedes older (C06)
5. Physical evidence (GPS, invoice) outweighs stated intent (email) (C07)
6. Different measurement methods produce legitimately different values (C01)
7. Same commodity from different market sources has legitimately different
   prices (C02)

## Background

Routine cooperative operations: seasonal planning meetings, equipment
scheduling, contractor bookings, irrigation allocation, market updates,
member newsletters, field days, training events, export documentation,
biosecurity inspections, grant applications, insurance renewals. ~70
memories providing realistic noise.
