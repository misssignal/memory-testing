# Story Bible — Experiment 12: Privacy Boundaries / Namespace Isolation

## Setting

**Nexus Hub** — a technology incubator in Austin, TX housing four startups that
share physical space, IT infrastructure, and some equipment but maintain strict
information boundaries between their proprietary work. Timeline: Q1–Q4 2032.

## Tenants

| ID   | Name             | Domain               | Project Codename(s)           |
|------|------------------|-----------------------|-------------------------------|
| T-PR | Prism Analytics  | Data analytics / ML   | Phoenix (real-time dashboard), Lens |
| T-VB | Verdant Bio      | Agricultural biotech  | Canopy (crop optimization), Bloom   |
| T-HE | Helios Energy    | Clean energy / solar  | Phoenix (solar optimizer), Beacon   |
| T-CL | Cirrus Labs      | Cloud infrastructure  | Nimbus (edge compute), Stratus      |

**Key collision**: Prism and Helios both have a project called "Phoenix" —
completely different products in different domains.

## People

| ID  | Name           | Role                        | Tenant | Access Level  |
|-----|----------------|-----------------------------|--------|---------------|
| P01 | Dana Reyes     | Nexus Hub Facility Manager  | shared | facility_admin|
| P02 | Arin Mehta     | Prism Analytics CEO         | T-PR   | tenant_admin  |
| P03 | Jordan Kim     | Prism → Cirrus (moves Q3)   | T-PR/T-CL | member    |
| P04 | Suki Tanabe    | Prism Analytics ML Engineer | T-PR   | member        |
| P05 | Leo Vasquez    | Verdant Bio CSO             | T-VB   | tenant_admin  |
| P06 | Maya Chen      | Verdant Bio Researcher      | T-VB   | member        |
| P07 | Rafe Okonkwo   | Helios Energy CTO           | T-HE   | tenant_admin  |
| P08 | Nina Petrov    | Helios Energy Engineer      | T-HE   | member        |
| P09 | Kwame Asante   | Cirrus Labs Founder         | T-CL   | tenant_admin  |
| P10 | Lia Torres     | External investor / guest   | shared | guest         |

## Cases

### C01 — Basic namespace isolation (Q1)
- Each tenant generates private memories about their core projects
- Prism has ML model development data; Verdant has gene editing results;
  Helios has solar cell efficiency numbers; Cirrus has infrastructure benchmarks
- **Test**: A query in Tenant A's namespace should never return Tenant B's private data
- **Adversarial trap**: All four tenants discuss "performance metrics" — same vocabulary,
  different numbers, different contexts

### C02 — Cross-tenant alias collision (Q1–Q2)
- Prism's "Phoenix" is a real-time analytics dashboard (v1.0–v3.2)
- Helios's "Phoenix" is a solar panel efficiency optimization algorithm
- Both are active simultaneously; both generate memories with "Phoenix" in the text
- **Test**: A query about "Phoenix" must disambiguate by namespace context
- **Adversarial trap**: Embedding similarity between "Phoenix performance improved by 15%"
  (Prism) and "Phoenix output increased by 15%" (Helios) is extremely high

### C03 — Access level hierarchy (Q1–Q3)
- Four levels: facility_admin > tenant_admin > member > guest
- facility_admin: sees shared + all tenant ops metadata (not IP)
- tenant_admin: sees own tenant's everything + shared
- member: sees own tenant's non-admin data + shared
- guest: sees only curated shared/public data
- Admin-only memories: financials, HR decisions, legal matters
- **Test**: Query at member level should not surface tenant_admin-only content
- **Adversarial trap**: A member asks about "budget" — should see project budget (member)
  but not company burn rate (tenant_admin) or facility lease terms (facility_admin)

### C04 — Access revocation after departure (Q2–Q3)
- Jordan Kim works at Prism Analytics through Q2
- Q3: Jordan leaves Prism and joins Cirrus Labs
- Jordan's Prism knowledge becomes inaccessible in their new context
- Jordan's contributions to shared/public work remain visible
- **Test**: Post-move queries from Jordan's (Cirrus) context must not surface Prism private data
- **Adversarial trap**: Jordan authored some of the Prism memories. Authorship ≠ access.

### C05 — Mixed-scope summary leakage (Q2–Q3)
- Nexus Hub produces a quarterly "Innovation Spotlight" newsletter
- The newsletter should reference public milestones without leaking private details
- A naive summarizer might pull in: revenue numbers, patent details, unpublished results
- **Test**: Queries about the newsletter should not chase provenance into private data
- **Adversarial trap**: The newsletter says "Prism achieved a significant ML milestone" —
  a query asking "what milestone?" should not surface the private model accuracy numbers

### C06 — Cross-tenant authorized sharing (Q2–Q4)
- Prism and Verdant collaborate on "AgroViz" — a joint agricultural data visualization project
- A shared namespace is created for AgroViz data
- AgroViz data is visible to both Prism and Verdant, but NOT to Helios or Cirrus
- Each company's non-AgroViz data remains private to their own tenant
- **Test**: AgroViz queries from Helios context should return nothing
- **Adversarial trap**: AgroViz uses Prism's Phoenix engine internally — but querying
  "Phoenix" from Verdant's context should only surface AgroViz-relevant Phoenix details,
  not Prism's full Phoenix roadmap

### C07 — Private meeting in shared space (Q1–Q3)
- Conference Room A is shared infrastructure, used by all tenants
- When Verdant holds a private meeting in Room A, the content is scoped to Verdant
- The room booking is shared; the meeting content is private
- **Test**: "What happened in Conference Room A on March 15?" should return different
  answers depending on the querier's namespace
- **Adversarial trap**: The room name is shared metadata. The meeting content is private.
  A system that indexes by room name may leak across tenants.

### C08 — Cascading scope in derived documents (Q3–Q4)
- Facility quarterly report references each tenant's public milestones
- Tenant internal reports reference private details behind those milestones
- A query about the facility report should not cascade into tenant private data
- A summary built from the facility report should not inherit private-scope content
- **Test**: Following provenance from shared → private should be blocked at the boundary
- **Adversarial trap**: derived_from links cross the scope boundary. A system that
  follows derivation chains without checking scope will leak.

## Scope Model

```json
{
    "tenant": "T-PR|T-VB|T-HE|T-CL|shared",
    "access_level": "facility_admin|tenant_admin|member|guest",
    "project": "optional project tag",
    "shared_with": ["T-PR", "T-VB"]  // for cross-tenant sharing
}
```

## Namespace Rules (Ground Truth)

1. A memory with `tenant: "T-PR"` is visible only to T-PR members (and facility_admin for ops metadata)
2. A memory with `tenant: "shared"` is visible to all access levels ≥ guest
3. `access_level` restricts within a tenant: member cannot see tenant_admin-only memories
4. `shared_with` overrides tenant isolation for specific cross-tenant collaboration
5. Access revocation: after Jordan moves, their Prism-scoped memories are not accessible from Cirrus context
6. Derived documents inherit the MOST RESTRICTIVE scope of their sources
7. Shared-space logistics (room bookings) are shared; meeting content inherits the tenant's scope

## Background

Shared facility operations: building maintenance, IT announcements, social events,
reception desk logs, equipment schedules, cafeteria menu changes, parking lot updates.
~80 memories providing realistic shared-namespace noise.
