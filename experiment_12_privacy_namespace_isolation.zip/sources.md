# Sources — Experiment 12

## Source Type

Fully synthetic. No real companies, people, or technology incubators are represented.

## Design Rationale

The technology incubator setting was chosen because it naturally produces all privacy
boundary types:
- Multiple tenants with private IP (namespace isolation)
- Shared infrastructure (shared vs private memories)
- Different project codenames that can collide (alias collision)
- Hierarchical organizational access (access levels)
- Employee mobility between companies (access revocation)
- Joint ventures with selective data sharing (authorized sharing)
- Shared physical spaces used by private groups (scope inheritance)
- Reports that summarize across scope boundaries (cascading scope)

No real company, product, or person is referenced.
