# Experiment 12 — Privacy Boundaries / Namespace Isolation

## Research Question

Can memory from one context leak into another? Does the system enforce namespace
isolation, access hierarchies, authorized sharing boundaries, and access revocation?

## Story

**Nexus Hub** — a technology incubator housing four startups (Prism Analytics,
Verdant Bio, Helios Energy, Cirrus Labs) that share physical space and IT
infrastructure but maintain strict information boundaries.

## Corpus

- **161 memories** across 8 cases + background
- **50 queries** across 9 categories
- **10 perturbations** for controlled ablation/injection experiments
- **4 tenants** + shared namespace, 4 access levels

## Cases

| Case | Type | What It Tests |
|------|------|--------------|
| C01 | Namespace Isolation | Each tenant's private data stays in its own namespace |
| C02 | Alias Collision | "Phoenix" means different things to Prism vs Helios |
| C03 | Access Hierarchy | facility_admin > tenant_admin > member > guest |
| C04 | Access Revocation | Jordan moves from Prism to Cirrus; Prism data becomes inaccessible |
| C05 | Mixed-Scope Summary | Newsletter references milestones without leaking private details |
| C06 | Cross-Tenant Sharing | AgroViz joint project visible to Prism+Verdant only |
| C07 | Shared Space | Room bookings are shared; meeting content is private |
| C08 | Cascading Scope | Derived docs must not chase provenance across scope boundaries |

## Key Feature: Query Context

Many queries in this experiment include a `query_context` field specifying the
querier's tenant and access level. The same question asked from different contexts
should produce different (or empty) results. This is the core test.

## Files

```
memories.jsonl          — 161 memories in ingestion order
queries.jsonl           — 50 benchmark queries with query_context
truth_state.json        — ground truth including namespace rules
story_bible.md          — full narrative design
experimental_map.json   — experimental structure and metrics
seed_memories.jsonl     — first 40 memories for seed review
perturbations/manifest.json — 10 controlled perturbations
sources.md              — source type and design rationale
```
