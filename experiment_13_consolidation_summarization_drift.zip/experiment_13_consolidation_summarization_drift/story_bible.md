# Story Bible — Experiment 13: Consolidation / Summarization Drift

## Setting

**Cascade Institute** — a mid-sized oceanographic and climate research
institute on the Oregon coast. The institute studies Pacific Ocean
ecosystems, sea-level rise, and marine biodiversity. Timeline: 2028–2034.

The institute maintains a long-running observational record that gets
periodically summarized into reports, which get summarized into
meta-analyses, which get summarized into policy briefs — a natural
summarization cascade where details are progressively lost.

## People

| ID  | Name              | Role                              |
|-----|-------------------|-----------------------------------|
| P01 | Dr. Nadia Okafor  | Director, Cascade Institute       |
| P02 | Dr. Tomás Rivera  | Lead Oceanographer                |
| P03 | Dr. Yuki Tanaka   | Marine Biologist                  |
| P04 | Dr. Asha Patel    | Climate Modeler                   |
| P05 | Marcus Chen       | Data Analyst / Statistician       |
| P06 | Dr. Lena Gould    | Policy Liaison                    |
| P07 | Kira Johansson    | Graduate Researcher               |

## Data Layers (Summarization Cascade)

```
Layer 0: Raw observations (instrument readings, field notes, specimen counts)
Layer 1: Monthly data summaries (aggregated by researcher)
Layer 2: Quarterly research reports (written by lead scientists)
Layer 3: Annual synthesis reports (compiled by director)
Layer 4: Multi-year meta-analyses (peer-reviewed publications)
Layer 5: Policy briefs (distilled for legislators)
```

Each layer compresses the one below it. The experiment tracks what is
lost, distorted, or flattened at each compression step.

## Cases

### C01 — Qualifier Loss (2028–2030)
- Raw: "Sea surface temperature anomaly of +1.2°C ± 0.3°C (p=0.04,
  marginally significant) observed at Station K7 during August 2028"
- Monthly summary: "Significant temperature anomaly of +1.2°C at K7"
  (qualifier "marginally" dropped, error bar dropped)
- Quarterly report: "Notable warming detected at Station K7"
  (magnitude dropped)
- Annual synthesis: "Warming trends observed across monitoring stations"
  (station identity collapsed, plurality added)
- Policy brief: "The Pacific is warming" (all specificity lost)
- **Test**: At what layer does the system believe the temperature anomaly
  was "significant" vs "marginally significant"?
- **Adversarial trap**: The most-repeated version (quarterly+annual+policy)
  says "significant" — but the raw data says "marginally significant"

### C02 — Uncertainty Loss (2029–2031)
- Raw: "Model ensemble projects 15–45cm sea-level rise by 2050 (median 28cm,
  90% CI). Three of twelve models show >40cm."
- Summary: "Models project ~28cm sea-level rise by 2050"
  (range collapsed to median, CI dropped)
- Report: "Sea-level rise of approximately 30cm projected"
  (median rounded up, "approximately" vague)
- Synthesis: "Sea-level rise of 30cm expected by 2050"
  ("approximately" → "expected", sounds more certain)
- Policy brief: "30cm of sea-level rise will occur by 2050"
  ("expected" → "will", uncertainty eliminated)
- **Test**: Does the system preserve the original 15–45cm range, or report
  the compressed "30cm" as fact?
- **Adversarial trap**: The policy brief (most recent, authoritative-sounding)
  states certainty that the raw data explicitly flagged as uncertain

### C03 — Provenance Loss (2029–2032)
- Three separate studies contribute findings:
  - Study A (Rivera): Kelp forest decline in Sector 3
  - Study B (Tanaka): Sea urchin population explosion in Sector 3
  - Study C (Patel): Ocean acidification model for Sector 3
- A quarterly report merges them: "Sector 3 shows ecological decline
  consistent with acidification-driven urchin overgrazing"
- An annual synthesis cites this as: "Acidification is driving kelp loss"
- A meta-analysis cites the synthesis
- **Test**: Can the system trace the "acidification drives kelp loss" claim
  back to its three separate sources? Or does it attribute the merged
  conclusion to a single study?
- **Adversarial trap**: Study C (acidification model) never directly
  measured kelp or urchins — the causal link was inferred in the quarterly
  report's editorial synthesis, not in any single study

### C04 — Temporal Flattening (2028–2034)
- 2028: Salmon run count = 12,400 (drought year, historically low)
- 2029: Salmon run count = 18,200 (recovery)
- 2030: Salmon run count = 22,100 (strong year)
- 2031: Salmon run count = 14,800 (El Niño impact)
- 2032: Salmon run count = 19,500 (recovery)
- 2033: Salmon run count = 23,800 (new monitoring method, count ~8% higher)
- A summary says "Salmon runs averaged ~18,500 over 2028–2033"
- An annual report says "Salmon populations have remained stable"
- A policy brief says "Salmon populations are healthy"
- **Test**: The raw data shows significant year-to-year variability, a
  methodological change, and a drought impact. The summaries flatten this
  into "stable" and then "healthy."
- **Adversarial trap**: The 2033 count uses a new method with ~8% overcounting.
  Naively, it looks like growth. The raw data notes the methodology change;
  the summaries don't.

### C05 — Identity Collapse (2029–2032)
- Dr. Tanaka studies three distinct coral species:
  - Acropora digitifera (branching coral, heat-sensitive)
  - Pocillopora damicornis (cauliflower coral, moderate resilience)
  - Porites lobata (lobe coral, heat-tolerant)
- Raw data: each species has distinct bleaching thresholds and recovery rates
- Monthly summary: "branching corals and cauliflower corals showed bleaching;
  lobe corals remained healthy"
- Quarterly report: "Coral bleaching observed in sensitive species"
  (two species collapsed to "sensitive species")
- Annual synthesis: "Coral bleaching events documented"
  (all species identity lost)
- Policy brief: "Coral reefs are dying"
  (nuance of differential resilience lost entirely)
- **Test**: A query about "coral resilience" should distinguish between
  the three species. A system that only has the policy brief will say
  "corals are dying" — missing that Porites lobata is actually thriving.
- **Adversarial trap**: The summary chain makes it look like all corals
  are affected equally, when the raw data shows a 3× difference in
  bleaching rates between species

### C06 — Summary-of-Summary Drift (2030–2034)
- Original finding: "Station K7 recorded a 0.8°C temperature anomaly
  in Q2 2030, within normal interannual variability"
- First summary: "Temperature anomaly recorded at K7" (magnitude dropped)
- Second summary (quarterly): "Temperature anomalies detected at
  monitoring stations" (singular → plural, station identity lost)
- Third summary (annual): "Widespread temperature anomalies across
  the monitoring network" ("detected" → "widespread")
- Fourth summary (meta-analysis): "Pervasive warming trends documented
  throughout the Pacific monitoring system"
- Fifth summary (policy): "Dramatic ocean warming throughout the Pacific"
- **Test**: Each summarization step amplifies the claim. The original
  was "within normal variability"; the final version says "dramatic warming."
  A query about K7's 2030 temperature should return the original finding.
- **Adversarial trap**: The drift is monotonically toward alarm.
  The most frequently cited version (annual/meta) is the most distorted.

### C07 — Lossy Numeric Compression (2028–2033)
- Raw pH measurements at 6 stations (precise to 0.001):
  Station A: 8.102, B: 8.089, C: 7.998, D: 8.045, E: 8.112, F: 7.965
- Monthly summary: "pH ranges from 7.97 to 8.11" (individual stations lost)
- Quarterly: "Ocean pH averages approximately 8.05" (range collapsed)
- Annual: "Ocean pH remains above 8.0" (false — Station F is below 8.0)
- Policy: "Ocean pH is stable" (no numbers at all)
- **Test**: Station C and F are below 8.0. The annual summary's claim
  "above 8.0" is factually wrong for 2 of 6 stations. The system should
  not propagate this error.
- **Adversarial trap**: The annual summary is literally false for 33%
  of stations but is the most-cited version. The raw data contradicts
  the summary chain.

## Summarization Layers

Each memory has a `summary_layer` field (0–5) indicating its position
in the cascade. Derived_from links connect each layer to its source(s)
in the layer below.

## Ground Truth Invariants

1. Raw data (layer 0) is always the authoritative source
2. Higher layers are progressively less precise but never wrong about
   what they explicitly state — EXCEPT when a summary introduces an error
   (C07 annual "above 8.0" is explicitly wrong)
3. Qualifier loss: "marginally significant" ≠ "significant"
4. Uncertainty loss: a range ≠ its midpoint stated as fact
5. Provenance: a merged conclusion ≠ any single contributing study
6. Temporal flattening: an average ≠ a trend description
7. Identity collapse: "coral" ≠ specific species
8. Summary drift: each layer's distortion is cumulative
9. Numeric compression: a summary that contradicts raw data is wrong

## Background

Routine institute operations: equipment calibration logs, staff meetings,
grant applications, conference attendance, weather station maintenance,
vessel scheduling, public lectures, visiting researcher programs, lab
supply orders, IT system updates. ~60 memories providing realistic noise
across all summary layers.
