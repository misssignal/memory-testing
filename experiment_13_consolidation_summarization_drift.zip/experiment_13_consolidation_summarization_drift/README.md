# Experiment 13: Consolidation / Summarization Drift

## Overview
Tests whether memory systems preserve semantically important details
when raw observations are progressively compressed through summarization layers.

## Scenario
Cascade Institute, an oceanographic research institute, maintains data
that flows through 6 layers of summarization (raw → monthly → quarterly
→ annual → meta-analysis → policy brief). Each layer compresses the
one below, and each compression step can lose qualifiers, uncertainty
ranges, provenance, temporal detail, species identity, or numeric precision.

## Statistics
- Memories: 100
- Queries: 32
- Cases: 7 (C01–C07)
- Summary layers: 0–5

## Cases
- C01: Qualifier Loss — "marginally significant" → "significant"
- C02: Uncertainty Loss — 15–45cm range → "30cm will occur"
- C03: Provenance Loss — three studies merged into one causal claim
- C04: Temporal Flattening — variable counts → "stable" → "healthy"
- C05: Identity Collapse — three coral species → generic "corals are dying"
- C06: Summary-of-Summary Drift — non-significant finding → "dramatic warming"
- C07: Lossy Numeric Compression — precise pH → false "above 8.0" claim

## Key Adversarial Property
The most-cited, most-recent, most-authoritative-sounding version of each
finding is systematically the MOST distorted version. Systems that prefer
summary-level or recent sources over raw data will fail these tests.
