# Sources — Experiment 13

## Experiment Design
- Consolidation / Summarization Drift benchmark
- Tests information loss through progressive summarization layers

## Synthetic Scenario
- Cascade Institute: oceanographic research institute on Oregon coast
- 6-layer summarization cascade: raw → monthly → quarterly → annual → meta-analysis → policy brief
- 7 test cases covering qualifier loss, uncertainty loss, provenance loss, temporal flattening, identity collapse, summary drift, and lossy numeric compression

## No real-world data used
All observations, measurements, and institutional details are fictional.
