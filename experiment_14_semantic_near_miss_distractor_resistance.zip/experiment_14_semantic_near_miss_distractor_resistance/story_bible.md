# Story Bible — Experiment 14: Semantic Near-Miss / Distractor Resistance

## Setting

**Twin Bridges Racing** — a competitive sailing team based in Auckland,
New Zealand, preparing for the 2032 and 2036 Pacific Cup regattas. The
team operates two nearly identical racing yachts (Albatross and Petrel),
competes in multiple events with overlapping formats, and works with
vendors/contractors whose names and roles are deliberately similar.

The setting is designed to maximize semantic near-misses: two boats with
similar specifications, two race campaigns years apart with the same
structure, crew members who rotate between boats, equipment with similar
part numbers, and weather events that recur with similar but not identical
parameters.

## People

| ID  | Name              | Role                              |
|-----|-------------------|-----------------------------------|
| P01 | James Maitland    | Team Principal                    |
| P02 | Aroha Nikora      | Skipper, Albatross                |
| P03 | Aroha Nikora      | Skipper, Petrel (rotated 2035)    |
| P04 | Ben Hartley       | Skipper, Petrel (2031-2034)       |
| P05 | Mei-Lin Chen      | Head of Design                    |
| P06 | Riku Sørensen     | Sail Designer                     |
| P07 | Liam O'Brien      | Sail Trimmer, Albatross           |
| P08 | Liam O'Brien-Sato | Sail Trimmer, Petrel              |
| P09 | Ngaire Wallace    | Navigator                         |
| P10 | Dr. Sami Vasquez  | Sports Science / Performance      |

Note: P07 (Liam O'Brien) and P08 (Liam O'Brien-Sato) are different people
with near-identical names. P02/P03 represent the same person (Aroha Nikora)
who switches boats in 2035.

## Boats

| Boat     | Hull # | Design   | Keel     | Built |
|----------|--------|----------|----------|-------|
| Albatross| TB-001 | Mark IV  | Canting  | 2030  |
| Petrel   | TB-002 | Mark IV-B| Canting  | 2031  |

Nearly identical but Petrel has a 0.3m longer waterline, different keel
bulb weight (4,200 kg vs 4,050 kg), and a slightly different sail plan.

## Campaigns

### 2032 Pacific Cup Campaign
- Qualifying races: Auckland–Fiji (March 2032), Sydney–Hobart feeder (June 2032)
- Main event: Pacific Cup, San Francisco–Kauai (July 2032)
- Albatross: finished 3rd overall, 1st in class
- Petrel: retired with keel hydraulic failure at Mile 847

### 2036 Pacific Cup Campaign
- Qualifying races: Auckland–Fiji (March 2036), Sydney–Hobart feeder (June 2036)
- Main event: Pacific Cup, San Francisco–Kauai (July 2036)
- Albatross: finished 2nd overall, 1st in class
- Petrel: finished 5th overall, 2nd in class

## Cases

### C01 — Wrong Entity, Right Description
- Albatross and Petrel have overlapping but distinct performance profiles
- Query about "the boat that retired in the 2032 Pacific Cup" should return
  Petrel, not Albatross (which finished 3rd)
- Albatross's 2032 performance data is a strong distractor because it's from
  the same race, same team, similar boat
- **Trap**: Embedding similarity between Albatross and Petrel data is very high

### C02 — Wrong Time, Right Entity
- The 2032 and 2036 campaigns have similar structure
- Auckland–Fiji 2032 had 25-knot NE trade winds; Auckland–Fiji 2036 had 22-knot NE trade winds
- A query about "wind conditions in the 2036 Auckland–Fiji race" should not
  retrieve the 2032 data despite nearly identical descriptions
- **Trap**: "Auckland–Fiji race with NE trade winds" describes both events

### C03 — Near-Identical Events
- Two separate keel inspections:
  - 2031-09: routine annual inspection, minor surface corrosion, cleared for racing
  - 2033-11: post-incident inspection after Petrel's 2032 retirement, found
    fatigue crack in hydraulic mount
- Both events share: keel, inspection, hydraulic, Petrel
- **Trap**: The events are lexically near-identical but have opposite outcomes

### C04 — Reused Phrases / Template Language
- Equipment maintenance logs use standardized template language:
  "Sail inventory check completed. [N] sails inspected, [M] requiring repair,
   [K] recommended for replacement."
- Five separate sail inventories (2031, 2032 pre-race, 2033, 2035, 2036 pre-race)
  produce nearly identical text with different numbers
- **Trap**: Vector similarity between all five is extremely high; only the
  numbers and dates distinguish them

### C05 — Correct Answer Uses Different Terminology
- The keel hydraulic system is described in engineering docs as "hydraulic
  ram actuator assembly (HRAA)"
- Race incident reports call it "keel mechanism" or "keel pivot system"
- Crew logs call it "the ram" or "keel jack"
- **Trap**: A query about "the hydraulic ram actuator assembly" should
  retrieve crew logs that say "the ram," but embedding distance is large

### C06 — Name Collision (O'Brien vs O'Brien-Sato)
- Liam O'Brien (P07) trims sails on Albatross
- Liam O'Brien-Sato (P08) trims sails on Petrel
- Memories about "Liam" or "O'Brien" are ambiguous without boat context
- In 2035, Liam O'Brien transfers to shore team; Liam O'Brien-Sato remains
- **Trap**: Many memories mention "Liam" without last name

### C07 — Misleading Embedding Proximity
- A weather briefing for the 2032 Pacific Cup describes "tropical depression
  approaching from the southwest, expected to strengthen to tropical storm"
- A separate memory discusses "team morale depression after Petrel's retirement,
  which strengthened resolve for 2036"
- These share: depression, strengthen, 2032/Pacific Cup context
- **Trap**: Pure embedding similarity would surface the morale memory for
  a weather query

## Equipment Part Numbers

Deliberately similar part numbers to test retrieval precision:
- Mainsail: SL-4401-A (Albatross), SL-4401-P (Petrel)
- Jib: SL-4402-A (Albatross), SL-4402-P (Petrel)
- Spinnaker: SL-4410-A (Albatross), SL-4410-P (Petrel)
- Keel hydraulic ram: HR-2201 (Albatross), HR-2202 (Petrel)

## Ground Truth Invariants

1. Albatross ≠ Petrel (distinct boats, distinct performance)
2. 2032 campaign ≠ 2036 campaign (distinct events, similar structure)
3. Liam O'Brien ≠ Liam O'Brien-Sato (different people)
4. Routine inspection ≠ post-incident inspection (different outcomes)
5. Each sail inventory is a distinct event despite template similarity
6. Different terminology for the same system must resolve to one referent
7. Semantic similarity ≠ factual relevance
8. Part number suffix determines boat assignment

## Background

Routine sailing team operations: boat maintenance, crew training, weather
briefings, sponsor events, media coverage, travel logistics, fitness testing,
sail development, rigging upgrades, port arrivals/departures, shore team
coordination, catering, accommodation, debrief sessions. ~70 memories
providing realistic noise.
