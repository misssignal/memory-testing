# Experiment 14: Semantic Near-Miss / Distractor Resistance

## Research Question
Does semantic/embedding similarity dominate over factual relevance in memory retrieval?

## Setting
Twin Bridges Racing — competitive sailing team based in Auckland, NZ.
Two nearly identical yachts (Albatross and Petrel), two campaign cycles (2032, 2036).

## Cases
- C01: Wrong Entity, Right Description (Albatross vs Petrel)
- C02: Wrong Time, Right Entity (2032 vs 2036)
- C03: Near-Identical Events (two keel inspections, opposite outcomes)
- C04: Reused Phrases / Template Language (sail inventories)
- C05: Correct Answer Uses Different Terminology (HRAA aliases)
- C06: Name Collision (O'Brien vs O'Brien-Sato)
- C07: Misleading Embedding Proximity (depression polysemy)

## Corpus Size
- Memories: 80
- Queries: 25
