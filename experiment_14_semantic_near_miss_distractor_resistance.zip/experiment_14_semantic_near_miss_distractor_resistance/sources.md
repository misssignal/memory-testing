# Sources — Experiment 14

## Source Type
Fully synthetic. All events, people, boats, and races are fictional.

## Narrative Basis
Competitive offshore sailing (Pacific Cup format). Setting chosen because:
- Two boats on one team creates natural entity confusion
- Multi-year campaigns create temporal near-misses
- Equipment with part numbers creates template similarity
- Crew rotations create name collision opportunities
- Weather terminology has polysemy (depression = weather system vs morale)

## Ground Truth
All facts are author-defined with no ambiguity in the story bible.
