# Stage 3 Experimental Map — Seed Coverage

The full Stage 3 design defines 40 adversarial traps. The Stage 4 seed directly exercises the highest-value subset:

- chronological control
- global shuffled ingestion
- decisive historical evidence arriving after newer world state
- correction before original
- within-lineage derived-before-source
- exact/semantic replay
- restart overlap
- old state-setting event replay after later transition
- historical belief preservation
- observation time vs authored time
- retrospective interpretation without retroactive knowledge
- provenance-root counting
- partial-ingestion calibration
- causal restraint

## Primary failure signatures

1. Last-write-wins temporal overwrite
2. Ingestion time mistaken for event time
3. Correction lost when child arrives before parent
4. Replay inflation
5. Derived representation counted as independent evidence
6. Old evidence reverting FC-4.8.3 current state
7. Later evidence rewriting historical actor beliefs
8. Clairvoyant answers at incomplete checkpoints
9. Failure to converge after restart/replay
10. False causal certainty
