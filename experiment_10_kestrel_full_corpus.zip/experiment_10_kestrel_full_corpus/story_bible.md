# Project Kestrel — Story Bible

Aster Aeronautics is conducting a remote flight-test campaign for K4-002 at Red Mesa Flight Test Range.

## Locked objective truth

On the evening before Flight 17, FC-4.8.2 is deployed:
- FCC-A succeeds and runs FC-4.8.2.
- FCC-B verification fails and retains FC-4.8.1.
- DT-3 records the failure locally while external synchronization is unavailable.

Before Flight 17, the central dashboard incorrectly appears to show both FCCs on FC-4.8.2 because decisive DT-3 evidence has not synchronized.

During Flight 17 on 2031-05-18:
- FCC-A runs FC-4.8.2.
- FCC-B runs FC-4.8.1.
- A brief control oscillation occurs.
- The maneuver is aborted and K4-002 lands safely.

R7 captures direct handshake evidence but its data reach the central store roughly two days late. DT-3 records arrive later still.

Jonah Malik initially records both post-flight FCC indicators as normal, then corrects the record to state that FCC-B's indicator was amber.

Novalyn supplier analysis is represented internally before the primary supplier record is ingested. Derived representations do not constitute independent evidence.

On 2031-05-21 FCC-B is deliberately updated to FC-4.8.3. Old Flight 17 evidence arriving afterward must not revert current state.

## Four clocks

The benchmark distinguishes:
1. event_time — when the world event occurred,
2. observation_time — when an actor/system observed it,
3. authored_time — when an artifact was created,
4. ingestion_time — when the memory system received it.

Delivery manifests manipulate delivery behavior without rewriting the canonical world.

## Causal restraint

The seed does not establish that the configuration mismatch was the sole cause of the Flight 17 oscillation.
