# Experiment 10 — Project Kestrel Full Corpus

Adversarial family: **Ingestion Order / Late Arrival / Replay Invariance**

- Canonical memories: **500**
- Benchmark queries: **120**
- Primary delivery runs: **14**

## Core invariant
**Ingestion order is transport history, not world history.**

The accepted Stage 4 Flight 17 seed is preserved and expanded into a living campaign with normal operations, harmless corrections, instrument clock-skew cases, genuinely unresolved same-second ordering, harmless late archive backfills, confidence-reducing late evidence, supplier false leads, post-remediation FC-4.8.3 checks, replay envelopes, and late-discovery-vs-late-occurrence controls.

Canonical Flight 17 truth remains FCC-A=FC-4.8.2 and FCC-B=FC-4.8.1. R7 and DT-3 independently establish the mismatch. FCC-B is deliberately updated to FC-4.8.3 on May 21. Old Flight 17 evidence must never revert the later current state. The corpus does not establish the mismatch as the sole cause of the oscillation.

Delivery manifests reference the same canonical `memories.jsonl`; they do not rewrite the evidence world.
