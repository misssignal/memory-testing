# Stage 4 Seed Review

Status: ACCEPTED FOR EXPANSION

## Strengths
- Four-clock temporal model is represented in real records.
- Flight 17 FC-4.8.1 vs later FC-4.8.3 creates a strong historical/current-state trap.
- Early checkpoints reward justified uncertainty rather than eventual-ground-truth guessing.
- R7 produces multiple derived representations without increasing independent root count.
- Jonah's correction is deterministic and suitable for correction-before-original testing.
- Retrospective interpretation is separated from contemporaneous knowledge.

## Expansion needs
- Add order-sensitive threads outside FCC configuration.
- Add harmless late evidence and harmless replay controls.
- Add late evidence that weakens confidence.
- Add genuinely unresolved same-time ordering cases.
- Add transport-envelope replay metadata.
- Surround Flight 17 with more normal campaign work and parallel engineering activity.

Target full corpus: roughly 425–550 canonical memories.
