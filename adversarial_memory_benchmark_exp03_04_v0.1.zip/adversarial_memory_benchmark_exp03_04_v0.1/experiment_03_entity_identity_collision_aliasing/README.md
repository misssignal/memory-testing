# Experiment 03 — Entity Identity, Collision & Aliasing

Story: **The Two Harbors**

Records: 200
Queries: 75

## Primary families
A same-name people; B renamed entity; C fork/split; D partial merge; E alias reuse;
F role-based ambiguity; G generation confusion; H similar-but-unrelated entities;
I conflicting/corrected/unresolved identity evidence; J cross-context identity.

## Important parser note
`_oracle` is development metadata. Blind runs should strip it. `subject_entity_id` may also be
hidden for system-under-test conditions. Genuine ambiguity is intentional and should not be forcibly resolved.
