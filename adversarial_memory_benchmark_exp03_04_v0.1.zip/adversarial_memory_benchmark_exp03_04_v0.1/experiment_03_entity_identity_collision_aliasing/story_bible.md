# Story Bible — Experiment 03: The Two Harbors

## Research target
Can the system preserve entity identity across name collisions, aliases, renames, forks, role changes, generations, corrections, and genuine ambiguity?

## Core lineage

```text
Harbor
├── Northstar (corporate continuation)
│   ├── Northstar Classic (retrospective label)
│   └── Northstar Next / Northstar 2 / NS2 / "Harbor 2"
└── Harbor Community (community fork)
```

## Signature identity traps

- Alex Chen (`person_0017`) and Alexander Chen (`person_0032`) overlap on Harbor.
- Alexandra Chen (`person_0064`) later receives the recycled `achen` username.
- Jordan Lee is incorrectly credited for a review actually performed by Jordan Leigh; an authoritative correction resolves it.
- A 2023 proposal signed `A. Chen` remains genuinely unresolved between two candidates.
- `Dock` names Harbor Deploy Service in 2023–2026 and Northline Artifact Gateway from 2027 onward.
- "the maintainer" changes referent across project and time.
- Northstar and Harbor Community share ancestry but are not post-fork identical.
- Their 2028 interoperability agreement merges selected governance work, not the projects.
- NorthStar HR, Northstar Labs, HARBOR protocol, and Harbour are lexical neighbors but unrelated entities.

## Oracle principle
Identity is represented as a time- and context-qualified relationship, not a global alias dictionary.
Some records intentionally remain ambiguous.
