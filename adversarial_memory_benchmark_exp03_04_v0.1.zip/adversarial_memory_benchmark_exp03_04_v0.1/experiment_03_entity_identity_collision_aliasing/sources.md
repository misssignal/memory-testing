# Sources

This story is fully synthetic. No public project history is being asserted as factual.

Source types inside the corpus are fictional benchmark artifacts: audit records, chat messages, meeting notes, archive indexes, and retrospective summaries.
