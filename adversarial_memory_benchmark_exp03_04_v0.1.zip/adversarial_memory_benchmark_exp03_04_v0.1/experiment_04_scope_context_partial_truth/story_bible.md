# Story Bible — Experiment 04: Aurora Global

## Research target
Can the system preserve the validity envelope of a claim across subsystem, environment, platform,
geography, organization, permissions, version, release channel, customer class, employment class, and time?

## Core system

```text
Relay
├── Telemetry
├── Command
├── Scheduler
├── Reporting
├── Beacon
├── Remote Snapshot
└── Edge Agent
```

## Signature scope traps

- EU Telemetry moves to Kafka before North America; Command remains RabbitMQ.
- Selected development uses SQLite.
- Nagoya temporarily uses a NATS bridge.
- EU ordinary production deployments need two approvals, with a temporary Stuttgart exception.
- Severity-1 hotfixes may use post-hoc approval.
- Beacon fails only on Windows ARM + Relay 4.1 + stable; 4.2 fixes it.
- A scoped workaround erodes into folklore and is misapplied during the Turin Linux incident.
- External vendors in Europe lose one Beacon admin mode; this is not a blanket ban.
- Riley prefers different languages by task context.
- Remote Snapshot has a nested multi-dimensional availability envelope.

## Oracle principle
A claim is not globally true merely because it is true somewhere. Missing scope and global scope
are distinct states.
