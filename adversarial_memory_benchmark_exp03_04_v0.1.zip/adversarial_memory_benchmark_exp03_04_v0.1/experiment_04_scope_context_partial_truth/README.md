# Experiment 04 — Scope, Context & Partial Truth

Story: **Aurora Global**

Records: 200
Queries: 75

## Primary families
A local/global; B environment; C platform; D geography; E organization; F permissions;
G temporary exceptions; H version; I release channel; J person-specific preferences;
K policy exceptions; L negative scope; M nested scope; X validity-envelope erosion.

## Important parser note
Null scope is not equivalent to global. `_oracle.scope_state` is development metadata and should be
stripped for blind runs. Several high-frequency summaries are intentionally less precise than their
source memories.
