# Experiment Map

## Experiment 03
A same-name people; B rename; C fork/split; D partial merge; E alias reuse; F role ambiguity;
G generation confusion; H similar unrelated entities; I conflicting/corrected/unresolved evidence;
J cross-context identity; X referential erosion.

Primary diagnostics: false merge, false split, identity leakage, fork contamination, alias resolution,
historical alias resolution, role resolution, appropriate abstention.

## Experiment 04
A local/global; B environment; C platform; D geography; E organization; F permissions;
G temporary exception; H version; I branch/release; J contextual preference; K policy exception;
L negative scope; M nested scope; X validity-envelope erosion.

Primary diagnostics: scope preservation, qualifier retention, scope-expansion distance,
exception normalization, stale-truth persistence, negative-scope leakage, nested-scope completeness.
