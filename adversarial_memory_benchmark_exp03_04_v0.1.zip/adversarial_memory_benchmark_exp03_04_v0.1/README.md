# Adversarial Memory Benchmark — Experiments 03 & 04 (v0.1)

Parser-ready synthetic benchmark bundle.

## Contents

- `experiment_03_entity_identity_collision_aliasing/`
- `experiment_04_scope_context_partial_truth/`
- `schema.json`
- `manifest.json`

Each experiment mirrors the earlier benchmark packaging pattern:

- `README.md`
- `story_bible.md`
- `memories.jsonl`
- `truth_state.json`
- `provenance.json`
- `queries.jsonl`
- `sources.md`
- `ingestion_chronological.jsonl`
- `ingestion_shuffled.jsonl`
- `ingestion_late_arrival.jsonl`
- `perturbations/`

## Scale

This v0.1 bundle contains:

- Experiment 03: 200 memories, 75 queries
- Experiment 04: 200 memories, 75 queries

These are not meaningless fillers. Repetition is used deliberately as an experimental variable:
casual paraphrases, authoritative records, corrections, stale summaries, alias collisions,
scope erosion, temporal exceptions, and high-frequency distractor claims.

## Hidden fields

`memories.jsonl` contains an `_oracle` object for benchmark development. A production harness
should be able to strip `_oracle`, `subject_entity_id`, `truth_role`, and/or normalized `scope`
fields depending on the condition being tested.

## Important semantic distinction

A null scope value is not automatically equivalent to "global." The oracle truth-state files
distinguish `global`, `specified`, `unknown`, `omitted`, and `not_applicable` where relevant.

## Status

This is intentionally an expanded Stage-4 / parser-validation corpus. It already reaches the
minimum requested 200-memory scale for each experiment, but Stage 5/6 can still expand the
narrative density and controlled perturbation grid substantially.
