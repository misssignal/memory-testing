# Story Bible — Experiment 16: Multi-hop Dependencies

## Setting

**Hōkūleʻa Transit Authority (HTA)** — a fictional Pacific island
metropolitan transit system (2030–2036) serving a chain of interconnected
islands via bus, ferry, and light rail. The system has complex route
dependencies where delays on one line cascade through transfers, equipment
is shared between depots, staff rotate between divisions, and budget
decisions ripple across the network.

The setting maximizes multi-hop reasoning: to answer "Why was Route 12
late on March 5?", a system must chain from the delay report → to the
vehicle assignment → to the maintenance record → to the parts order → to
the budget cut that delayed the parts.

## People

| ID  | Name               | Role                           |
|-----|--------------------|--------------------------------|
| P01 | Keanu Lani         | General Manager                |
| P02 | Malia Reyes        | Operations Director            |
| P03 | Tane Parata        | Bus Division Chief             |
| P04 | Leilani Kim        | Ferry Division Chief           |
| P05 | Jiro Tanaka        | Light Rail Division Chief      |
| P06 | Anika Sharma       | Maintenance Director           |
| P07 | Ravi Mehta         | Budget & Finance               |
| P08 | Kira Nakamura      | Scheduling Coordinator         |
| P09 | Sione Vunipola     | Depot Manager, East            |
| P10 | Grace Okonkwo      | Depot Manager, West            |

## Infrastructure

| Asset      | Type       | Depot | Serves           |
|------------|------------|-------|------------------|
| Bus-101    | Bus        | East  | Routes 10, 12    |
| Bus-102    | Bus        | East  | Routes 10, 14    |
| Bus-103    | Bus        | West  | Routes 20, 22    |
| Bus-104    | Bus        | West  | Routes 20, 24    |
| Ferry-A    | Ferry      | Harbor| Cross-island     |
| Ferry-B    | Ferry      | Harbor| Cross-island     |
| LR-01      | Light Rail | Central| Green Line      |
| LR-02      | Light Rail | Central| Green Line      |
| LR-03      | Light Rail | Central| Blue Line       |

## Routes & Transfers

- Route 10 (East–Downtown) → Transfer at Central Station to Green Line
- Route 12 (East–Harbor) → Transfer at Harbor to Ferry
- Route 20 (West–Downtown) → Transfer at Central Station to Blue Line
- Route 22 (West–Harbor) → Transfer at Harbor to Ferry
- Green Line → Transfer at Midtown to Route 10 or Blue Line
- Blue Line → Transfer at University to Route 20
- Ferry cross-island → connects to West depot bus routes

## Cases

### C01 — Chain of Causation (Maintenance → Delay)
- Budget cut (Q3 2032) → delayed parts procurement → extended Bus-101
  maintenance → Bus-102 pulled from Route 14 to cover Route 12 →
  Route 14 cancellation → passenger complaints → media coverage
- 5-hop causal chain

### C02 — Transfer Cascade
- Ferry-A engine failure (March 2033) → increased load on Ferry-B →
  ferry schedule change → bus connections missed at Harbor →
  Route 12 and 22 passengers stranded → emergency bus deployed from
  East depot → Route 10 frequency reduced → Green Line overcrowding
- 6-hop cascade through the network

### C03 — Staff Dependency Chain
- Jiro Tanaka (LR chief) goes on leave → Tane Parata covers both bus
  and LR → Tane delegates bus scheduling to Kira → Kira reassigns
  Bus-103 from Route 20 to Route 22 (her old route) → Route 20 gaps →
  passenger shift to Blue Line → Blue Line overcrowding complaints
- Authority chain + operational consequence

### C04 — Budget Chain (Allocation → Service Impact)
- Federal funding cut → HTA budget reduction → Ravi Mehta restructures
  allocations → ferry maintenance deferred → Ferry-B hull inspection
  delayed → maritime authority grounds Ferry-B → single-ferry operation →
  cross-island service halved
- Financial chain with regulatory consequence

### C05 — Information Chain (Report → Decision → Outcome)
- Ridership survey (incorrect methodology) → inflated patronage estimate
  → board approves Route 24 expansion → buses reallocated from Route 20 →
  Route 20 service cuts → ridership drops further → survey error discovered
  → Route 24 expansion reversed but Route 20 hasn't recovered
- Decision chain with feedback loop

### C06 — Equipment Provenance Chain
- LR-03 brake actuator from supplier X → supplier X acquired by
  company Y → company Y changes part specification → replacement part
  doesn't fit LR-03 → emergency sourcing from original spec → delay →
  LR-03 out of service 3 weeks → Blue Line single-car operation
- Supply chain tracing

### C07 — Temporal Dependency Chain
- 2030 route plan → 2031 infrastructure investment → 2032 construction
  disruption → 2033 new station opens → 2034 ridership patterns shift →
  2035 schedule revision → 2036 performance review references all prior
  decisions
- Year-over-year chain where each year depends on the prior

## Ground Truth Invariants

1. Each effect has a specific cause; retrieving the effect without the
   cause (or vice versa) is incomplete
2. Intermediate nodes in a chain are as important as endpoints
3. A 3-hop question requires all 3 nodes; partial chains are wrong
4. Chains can branch (one cause → multiple effects)
5. Chains can merge (multiple causes → one effect)
6. Temporal ordering of the chain matters
7. Removing any link breaks the chain
