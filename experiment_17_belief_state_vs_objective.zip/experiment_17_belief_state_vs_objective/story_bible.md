# Story Bible — Experiment 17: Belief State vs Objective State

## Setting

**Cascadia Wildfire Response Network (CWRN)** — a multi-agency wildfire
monitoring and response coordination center serving the Pacific Northwest
(2031–2036). The center integrates data from ground crews, aerial
surveillance, satellite imagery, weather stations, and public reports to
manage wildfire detection, containment, and evacuation.

The setting maximizes belief-vs-reality divergence: different agents hold
different beliefs about fire perimeters, containment status, evacuations,
and resource positions. Objective ground truth (what actually happened)
often differs from what any single observer believed at the time.

## People

| ID  | Name               | Role                              |
|-----|--------------------|-----------------------------------|
| P01 | Marcus Chen        | CWRN Director                     |
| P02 | Sarah Whitehorse   | Fire Behavior Analyst             |
| P03 | Diego Ruiz         | Ground Crew Chief (South Sector)  |
| P04 | Priya Johal        | Ground Crew Chief (North Sector)  |
| P05 | Tom Redfeather     | Aerial Surveillance Lead          |
| P06 | Elena Volkov       | Satellite Analysis Lead           |
| P07 | James Park         | Weather Station Coordinator       |
| P08 | Nadia Al-Rashid    | Evacuation Coordinator            |
| P09 | Ben Kowalski       | Resource Logistics Manager        |
| P10 | Mei-Ling Wu        | Public Information Officer         |

## Infrastructure

| Asset          | Type            | Location       |
|----------------|-----------------|----------------|
| Station Alpha  | Ground base     | South sector   |
| Station Bravo  | Ground base     | North sector   |
| Helo-1         | Helicopter      | Mobile         |
| Helo-2         | Helicopter      | Mobile         |
| Tanker-3       | Air tanker      | Regional base  |
| Sat-Sentinel   | Satellite feed  | Orbital        |
| WX-North       | Weather station | North ridge    |
| WX-South       | Weather station | South valley   |

## Cases

### C01 — Fire Perimeter Disagreement
- Ground crew reports fire at 500 acres (based on visible smoke line)
- Aerial surveillance reports 800 acres (infrared shows fire beyond smoke)
- Satellite analysis reports 650 acres (resolution limitations)
- Actual perimeter: 780 acres (later confirmed by post-fire mapping)
- Each observer's belief was internally consistent but wrong
- The "best" estimate at any point depends on which source you trust

### C02 — False Containment Report
- South crew reports containment line complete on western flank
- Night wind shift reignites beyond containment line
- Morning aerial finds fire has jumped containment
- 6-hour window where belief state ("contained") diverged from reality
- Resource allocation decisions made during false-containment window

### C03 — Evacuation Status Confusion
- Nadia orders Zone 3 evacuation at 14:00
- Communication failure: some residents receive order, others don't
- Public information officer announces evacuation complete at 18:00
- Ground crew discovers 12 households still in Zone 3 at 20:00
- Objective state: evacuation incomplete; belief state: evacuation done

### C04 — Resource Position Misbelief
- Logistics shows Tanker-3 at Regional Base (scheduled position)
- Tanker-3 actually diverted to neighboring fire (mutual aid)
- CWRN plans air support assuming Tanker-3 available
- Plans fail when Tanker-3 doesn't arrive
- Stale vs. real-time position data

### C05 — Weather Prediction vs. Reality
- Weather station predicts wind shift at 06:00 from NW to SE
- Fire behavior analyst plans based on predicted shift
- Actual wind shift occurs at 03:00 (3 hours early)
- Fire behavior between 03:00-06:00 diverges from all predictions
- Forecasters believed conditions stable; reality was already changing

### C06 — Damage Assessment Discrepancy
- Aerial rapid assessment: 23 structures destroyed
- Ground assessment (2 days later): 31 structures destroyed
- Insurance preliminary: 28 structures claimed
- Final verified count: 29 structures
- Different methodologies produce different "facts"

### C07 — Historical Fire Comparison Error
- Analyst compares current fire to 2028 Ridge Fire
- Cited 2028 fire as 12,000 acres; actual was 8,500 acres
- Plans scaled for larger fire than historical precedent warrants
- Over-allocation of resources based on inflated comparison
- Belief about historical fact diverges from historical reality

## Ground Truth Invariants

1. Every memory has a belief_holder who may or may not have correct info
2. Objective truth exists independently of any observer's belief
3. The same event can have multiple belief-state memories with different
   "facts" — all internally consistent, not all correct
4. Time matters: a belief can be correct at T1 and wrong at T2
5. Source reliability varies: satellite > aerial > ground for area,
   ground > aerial > satellite for detail
6. A query about "what happened" must distinguish between what was
   believed and what actually happened
7. Abstaining is correct when the memory store contains only beliefs
   with no objective confirmation
